import { subscriptions } from "@mock/mockData";
import ReactECharts from "echarts-for-react";

export default function Home() {
  const subSum = subscriptions.reduce((acc, sub) => acc + sub.price, 0);
  const totalSubs = subscriptions.length;
  const activeSubsCount = subscriptions.filter(
    (sub) => sub.status === "active"
  ).length;

  // 1. Фильтруем, сортируем и выводим только ближайшие подписки с окончанием времени
  const subActive = subscriptions
    .filter((sub) => sub.status === "active")
    .sort((a, b) => new Date(a.nextPayment) - new Date(b.nextPayment))
    .slice(0, 3);

  // --- 1. Сумма по категориям (pie) ---
  const categoryTotals = subscriptions.reduce((acc, sub) => {
    if (sub.status !== "active") return acc;
    acc[sub.category] = (acc[sub.category] || 0) + sub.price;
    return acc;
  }, {});
  const categoryOption = {
    title: { text: "Расходы по категориям", left: "center" },
    tooltip: { trigger: "item" },
    legend: { orient: "vertical", left: "left" },
    series: [
      {
        type: "pie",
        radius: "50%",
        data: Object.entries(categoryTotals).map(([cat, val]) => ({
          name: cat,
          value: val,
        })),
      },
    ],
  };

  // --- 2. По сервисам (bar) ---
  const activeSubs = subscriptions.filter((s) => s.status === "active");
  const serviceOption = {
    title: { text: "Топ подписок по цене", left: "center" },
    tooltip: {},
    xAxis: { type: "category", data: activeSubs.map((s) => s.name) },
    yAxis: { type: "value" },
    series: [
      {
        data: activeSubs.map((s) => s.price),
        type: "bar",
      },
    ],
  };

  // --- 3. По месяцам (line) ---
  const monthlyTotals = {};
  subscriptions.forEach((sub) => {
    if (sub.status !== "active") return;
    const month = new Date(sub.nextPayment).toLocaleString("ru-RU", {
      month: "short",
      year: "numeric",
    });
    monthlyTotals[month] = (monthlyTotals[month] || 0) + sub.price;
  });
  const monthlyOption = {
    title: { text: "Платежи по месяцам", left: "center" },
    tooltip: { trigger: "axis" },
    xAxis: { type: "category", data: Object.keys(monthlyTotals) },
    yAxis: { type: "value" },
    series: [
      { data: Object.values(monthlyTotals), type: "line", smooth: true },
    ],
  };

  return (
    <div className="flex flex-row h-full w-full bg-gray-200">
      <div className="flex flex-col items-start w-full m-4">
        <div className="flex flex-col w-full mb-4 border-b-2 pb-3">
          <div className="flex flex-col w-full mb-4">
            <h2>Общая сумма подписок</h2>
            <span className="text-[40px]">{subSum} $</span>
          </div>
          <p className="text-[20px]">Количество подписок : {totalSubs}</p>
          <h2>Активные подписки : {activeSubsCount}</h2>
        </div>
        <div className="flex w-full mb-4">
          <div className="flex flex-col w-full">
            <p className="mb-3">Ближайшие платежи</p>
            <table className="w-full">
              <thead>
                <tr>
                  <th className="border-b-2">Подписка</th>
                  <th className="border-b-2">Цена</th>
                  <th className="border-b-2">Категория</th>
                  <th className="border-b-2">Оплата</th>
                  <th className="border-b-2">Статус</th>
                </tr>
              </thead>
              {subActive.map((sub) => (
                <tbody className="w-full mb-5" key={sub.id}>
                  <tr>
                    <td className="border-b-1">{sub.name}</td>
                    <td className="border-b-1">{sub.price} $</td>
                    <td className="border-b-1">{sub.category}</td>
                    <td className="border-b-1">{sub.nextPayment}</td>
                    <td className="border-b-1">{sub.status}</td>
                  </tr>
                </tbody>
              ))}
            </table>
          </div>
        </div>
        <div className="flex flex-col w-full h-full mt-5">
          <ReactECharts
            option={categoryOption}
            className="max-h-[400px] mb-5 border-b-1"
          />
          <ReactECharts
            option={serviceOption}
            className="max-h-[400px] border-b-1"
          />
          <div className="col-span-2">
            <ReactECharts option={monthlyOption} className="max-h-[400px] mt-5" />
          </div>
        </div>
      </div>
    </div>
  );
}
