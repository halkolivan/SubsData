import { useState } from "react";

// import data
import { subscriptions as mockSubscriptions } from "@mock/mockData";

export default function MySubscriptions() {
  const [subscriptions, setSubscriptions] = useState(mockSubscriptions);
  const [sortRevers, setSortRevers] = useState(true);
  const [sortAscName, setSortAscName] = useState(true);
  const [sortActiveStatus, setSortActiveStatus] = useState(true);
  const [sortAscDate, setSortAscDate] = useState(true);
  const [sortAscCategory, setSortAscCategory] = useState(true);

  const sortByPrice = () => {
    const sorted = [...subscriptions].sort((a, b) =>
      sortRevers ? a.price - b.price : b.price - a.price
    );
    setSubscriptions(sorted);
    setSortRevers(!sortRevers);
  };

  const sortByName = () => {
    const sorted = [...subscriptions].sort((a, b) =>
      sortAscName ? a.name.localeCompare(b.name) : b.name.localeCompare(a.name)
    );
    setSubscriptions(sorted);
    setSortAscName(!sortAscName);
  };

  const sortByStatus = () => {
    const sorted = [...subscriptions].sort((a, b) =>
      sortActiveStatus
        ? a.status.localeCompare(b.status)
        : b.status.localeCompare(a.status)
    );
    setSubscriptions(sorted);
    setSortActiveStatus(!sortActiveStatus);
  };

  const sortByDate = () => {
    const sorted = [...subscriptions].sort((a, b) =>
      sortAscDate
        ? new Date(a.nextPayment) - new Date(b.nextPayment)
        : new Date(b.nextPayment) - new Date(a.nextPayment)
    );
    setSubscriptions(sorted);
    setSortAscDate(!sortAscDate);
  };

  const sortByCategory = () => {
    const sorted = [...subscriptions].sort(
      (a, b) =>
        sortAscCategory
          ? a.category.localeCompare(b.category) // A → Z
          : b.category.localeCompare(a.category) // Z → A
    );
    setSubscriptions(sorted);
    setSortAscCategory(!sortAscCategory);
  };

  return (
    <div className="flex flex-col gap-3 w-full bg-gray-100 bg-gray-200 pt-4 pb-4">
      <span className="text-[20px]">Мои подписки</span>
      <table className="w-full">
        <thead className="border-b-2">
          <tr>
            <th>
              <button
                onClick={sortByName}
                className="!bg-gray-200  hover:!border-gray-200  active:!border-gray-200  hover:text-blue-500"
              >
                Подписка {sortAscName ? "↑" : "↓"}
              </button>
            </th>
            <th>
              <button
                onClick={sortByPrice}
                className="!bg-gray-200  hover:!border-gray-200  active:!border-gray-200  hover:text-blue-500"
              >
                Цена {sortRevers ? "↑" : "↓"}
              </button>
            </th>
            <th>
              <button
                onClick={sortByCategory}
                className="!bg-gray-200  hover:!border-gray-200  active:!border-gray-200  hover:text-blue-500"
              >
                Категория {sortAscCategory ? "↑" : "↓"}
              </button>
            </th>
            <th>
              <button
                onClick={sortByDate}
                className="!bg-gray-200  hover:!border-gray-200 active:!border-gray-200 hover:text-blue-500"
              >
                След. оплата {sortAscDate ? "↑" : "↓"}
              </button>
            </th>
            <th>
              <button
                onClick={sortByStatus}
                className="!bg-gray-200  hover:!border-gray-200 active:!border-gray-200 hover:text-blue-500"
              >
                Статус {sortActiveStatus ? "↑" : "↓"}
              </button>
            </th>
          </tr>
        </thead>
        {subscriptions.map((sub) => (
          <tbody key={sub.id}>
            <tr className="">
              <td className="border-r-2 border-b-1">{sub.name}</td>
              <td className="border-r-2 border-b-1">
                {sub.price} {sub.currency}
              </td>
              <td className="border-r-2 border-b-1">{sub.category}</td>
              <td className="border-r-2 border-b-1">{sub.nextPayment}</td>
              <td className="border-b-1">{sub.status}</td>
            </tr>
          </tbody>
        ))}
      </table>
    </div>
  );
}
