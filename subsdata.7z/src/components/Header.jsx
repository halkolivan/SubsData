import { NavLink } from "react-router-dom";
// import images
import logo from "@assets/images/SubsDataImage32.png";

export default function Header() {
  return (
    <div className="flex justify-center mb-4 w-full ">
      <div className="flex justify-between w-full h-[50px] items-center p-2 gap-4 bg-gray-300 rounded-t-lg">
        <NavLink to="/">
          <img
            src={logo}
            alt="logo"
            className="transition-transform duration-300 hover:scale-110"
          />
        </NavLink>
        <NavLink to="/mysubscriptions">
          {({ isActive }) => (
            <h5
              className={
                (isActive ? "text-blue-500" : "text-gray-700") +
                " hover:text-blue-500 "
              }
            >
              Мои подписки
            </h5>
          )}
        </NavLink>
        <NavLink to="/settings">
          {({ isActive }) => (
            <h5
              className={
                (isActive ? "text-blue-500" : "text-gray-700") +
                " hover:text-blue-500 "
              }
            >
              Настройки
            </h5>
          )}
        </NavLink>        
        <h5 className="">Подписка +</h5>
        <h5 className="">Вход</h5>
        <h5 className="">Язык</h5>
      </div>
    </div>
  );
}
