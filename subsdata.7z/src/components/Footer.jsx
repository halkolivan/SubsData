export default function Footer() {
  return (
    <div className="flex bg-gray-300 gap-4 p-3 mt-4 justify-between rounded-b-lg">
      <span>Копирайт © | Томайлы Роман 2025</span>
      <span>«Privacy Policy / Terms of Service»</span>
      <span>Telegram : @tomayli80</span>
    </div>
  );
}
