import '../src/assets/styles/App.css';
import Router from "./Router";
import ReactDOM from "react-dom/client";

ReactDOM.createRoot(document.getElementById('root')).render(
    <Router/>
);


