import "./i18n";
import React from "react";
import Router from "./Router";
import "@assets/styles/App.css";
import { Suspense, useEffect } from "react";
import ReactDOM from "react-dom/client";
import { registerSW } from "virtual:pwa-register";
import { AuthProvider } from "@/context/AuthContext";
import { GoogleOAuthProvider } from "@react-oauth/google";

const clientId =
  "408629276793-90jf6aqt0lupftengqnodqd0dgnl2lck.apps.googleusercontent.com";


// Компонент App
function App() {
  useEffect(() => {
    // Регистрируем Service Worker только в production
    if (import.meta.env.PROD) {
      registerSW({
        onNeedRefresh() {},
        onOfflineReady() {},
      });
    }
  }, []);

  return (
    <GoogleOAuthProvider clientId={clientId}>
      <AuthProvider>
        <Suspense fallback={<div className="flex p-6 w-full justify-center items-center text-center">Загрузка...</div>}>
          <Router />
        </Suspense>
      </AuthProvider>
    </GoogleOAuthProvider>
  );
}

// Монтируем компонент в DOM
ReactDOM.createRoot(document.getElementById("root")).render(<App />);
