import express from "express";
import cors from "cors";
import bodyParser from "body-parser";

// Google API (пример для Google Drive)
import { google } from "googleapis";

const app = express();
app.use(cors()); // разрешаем CORS с любого фронтенда
app.use(bodyParser.json());

const PORT = 4000;

app.post("/save-subs", async (req, res) => {
  const { subscriptions } = req.body;
  console.log("Получены подписки:", subscriptions);

  // TODO: тут будет логика сохранения в Google Drive
  // Пока просто отправляем обратно
  res.json({ success: true, count: subscriptions.length });
});

app.listen(PORT, () =>
  console.log(`Server running on http://localhost:${PORT}`)
);
